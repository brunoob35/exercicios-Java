import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        //Cria o scanner
        Scanner scanner = new Scanner(System.in);
        System.out.print("Digite uma frase: ");
        //Le a frase completa
        String frase = scanner.nextLine();

        //Divide a frase em palavras, separando por espaços (um ou mais)
        String[] palavras = frase.trim().split("\\s+");
        //Mostra quantas palavras foram encontradas
        System.out.println("A frase contém " + palavras.length + " palavras.");

        //Fecha o scanner
        scanner.close();
    }
}
