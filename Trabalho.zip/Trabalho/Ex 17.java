import java.util.Scanner;
import java.util.Random;

public class Main {
    public static void main(String[] args) {
        //Scanner para ler o palpite do usuario
        Scanner scanner = new Scanner(System.in);
        //Objeto para gerar numero aleatorio
        Random rand = new Random();

        //Gera um numero entre 1 e 100
        int numeroSecreto = rand.nextInt(100) + 1;
        int tentativa, tentativas = 0;

        System.out.println("Tente adivinhar o número entre 1 e 100!");

        do {
            System.out.print("Digite seu palpite: ");
            //Le o palpite
            tentativa = scanner.nextInt();
            //Incrementa o numero de tentativas
            tentativas++;

            //Da dicas ao usuario
            if (tentativa < numeroSecreto) {
                System.out.println("Maior!");
            } else if (tentativa > numeroSecreto) {
                System.out.println("Menor!");
            } else {
                System.out.println("Parabéns! Você acertou em " + tentativas + " tentativas.");
            }
        } while (tentativa != numeroSecreto);

        //Fecha o scanner
        scanner.close();
    }
}
