import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        //Cria o objeto scanner para ler entrada do usuário
        Scanner scanner = new Scanner(System.in);
        System.out.print("Digite uma senha: ");
        //Le a senha digitada
        String senha = scanner.nextLine();

        //Verifica se a senha atende aos critérios
        if (senha.length() >= 8 &&
            senha.matches(".*[A-Z].*") &&
            senha.matches(".*[a-z].*") &&
            senha.matches(".*\\d.*")) {
            System.out.println("Senha válida!");
        } else {
            System.out.println("Senha inválida! A senha deve conter:");
            System.out.println("- Pelo menos 8 caracteres");
            System.out.println("- Pelo menos uma letra maiúscula");
            System.out.println("- Pelo menos uma letra minúscula");
            System.out.println("- Pelo menos um número");
        }

        //Fecha o scanner
        scanner.close();
    }
}
